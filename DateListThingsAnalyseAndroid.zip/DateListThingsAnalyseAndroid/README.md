# 说明

> **[DateListThingsAnalyse](https://github.com/emperinter/DateListThingsAnalyse) 的Android版本**

# Special Thanks

> 目前用的是AnyChart的可视化产品，对于NoCommercial的产品是免费的，其它则是要收费的。如有更好的开源替代产品欢迎留言，目前看到的产品基本没有词云图。还有的则是Echarts来开发。

- [可视化：https://github.com/AnyChart/AnyChart-Android](https://github.com/AnyChart/AnyChart-Android)
