package info.emperinter.DateListThingsAnalyseAndroid;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.*;

import java.util.ArrayList;
import java.util.List;

public class BarChartFragment extends AppCompatActivity {
    private LineChart lineChart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.barchart_fragment);

        setTitle("BarChartActivity");

        lineChart = findViewById(R.id.chart1);

        //无数据时显示
        lineChart.setNoDataText("没有获取到数据哦~");
        lineChart.setNoDataTextColor(Color.parseColor("#00bcef"));
        //初始化显示数据
        List<Float> floats = new ArrayList<>();
        floats.add(0.5f);
        floats.add(3f);
        floats.add(1f);
        floats.add(0.1f);
        List<Entry> entries = new ArrayList<>();
        for (int i = 0;i<floats.size();i++){
            entries.add(new Entry(i,floats.get(i)));
        }
        //将数据赋给数据集,一个数据集表示一条线
        LineDataSet lineDataSet = new LineDataSet(entries,"");
        LineData lineData = new LineData(lineDataSet);
        //不显示曲线点的具体数值
        lineData.setDrawValues(false);
        lineChart.setData(lineData);


    }


}