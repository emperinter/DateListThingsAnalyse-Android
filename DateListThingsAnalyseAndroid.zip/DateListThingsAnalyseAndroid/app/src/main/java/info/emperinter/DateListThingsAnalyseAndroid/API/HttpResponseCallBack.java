package info.emperinter.DateListThingsAnalyseAndroid.API;

import org.json.JSONException;

public interface HttpResponseCallBack {
    void getResponse(String response) throws JSONException;
}
